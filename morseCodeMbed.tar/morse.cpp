
#include "mbed.h"
#include <iostream>
#include <map>
#include <string>

#define DASH              150ms
#define DOT               50ms
#define GAPMorse          50ms
#define GAPLetter         100ms  

std::string decode(std::string text){
    std::map<char, std::string> morseCode;

    morseCode['A'] = ".-";
    morseCode['B'] = "-...";
    morseCode['C'] = "-.-.";
    morseCode['D'] = "-..";
    morseCode['E'] = ".";
    morseCode['F'] = "..-.";
    morseCode['G'] = "--.";
    morseCode['H'] = "....";
    morseCode['I'] = "..";
    morseCode['J'] = ".---";
    morseCode['K'] = "-.-";
    morseCode['L'] = ".-..";
    morseCode['M'] = "--";
    morseCode['N'] = "-.";
    morseCode['O'] = "---";
    morseCode['P'] = ".--.";
    morseCode['Q'] = "--.-";
    morseCode['R'] = ".-.";
    morseCode['S'] = "...";
    morseCode['T'] = "-";
    morseCode['U'] = "..-";
    morseCode['V'] = "...-";
    morseCode['W'] = ".--";
    morseCode['X'] = "-..-";
    morseCode['Y'] = "-.--";
    morseCode['Z'] = "--..";
    
    std::string morseText = "";
    for (char c : text) {
        if (c == ' ') {
            morseText += " ";
        } else {
            morseText += morseCode[std::toupper(c)] + " ";
        }
    }
    return morseText;
}
int blick_led(std::string morseText){
    DigitalOut led(LED3);
    for (char c : morseText) {
        if (c == '.'){
            led = false;
            ThisThread::sleep_for(DOT);
            led = true;
        }
        else if (c == '-'){
            led = false;
            ThisThread::sleep_for(DASH);
            led = true;
        }
        else{
            led = true;
            ThisThread::sleep_for(GAPLetter);
        }
        ThisThread::sleep_for(GAPMorse);
    }
    return 0;
}