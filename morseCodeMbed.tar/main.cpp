/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

 
//Matěj Lukáč a Jakub Koněrza
#include "mbed.h"
#include <iostream>
#include "morse.h"
#include <string>

int init(){
    DigitalOut led(LED3);
    led = true;
    return 0;
}

int exit(){
    DigitalOut led(LED3);
    led = true;
    return 0;
}

int main()
{
    bool run = true;
    init();
    // Initialise the digital pin LED1 as an output
    while (run){
        std::string morseText;
        morseText = decode("JAKUB KONERZA");
        blick_led(morseText);
        run = false;
    }
    exit();
}
