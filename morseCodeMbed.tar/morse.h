#define _MORSE_H

#include <string>
std::string decode(std::string text);
int blick_led(std::string morseText);
